<?php

return [
    'name' => 'Algebra Autentifikacija',
    'error_reporting' => 1
]

?>