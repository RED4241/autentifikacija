<?php
  require_once "core/init.php";
  Helper::getHeader('Home Page');
  Helper::getNav();
?>

<div class="row">
    <div class="card col-lg-6 offset-lg-3">
    <h5 class="card-title">Create an account</h5>
    <div class="card-body">
            <form method="POST">
            <div class="form-group">
                <label for="f_name">First Name</label>
                <input type="text" class="form-control" id="f_name" name="f_name" placeholder="Enter your first name">
            </div>
            <div class="form-group">
                <label for="surname">Last Name</label>
                <input type="text" class="form-control" id="surname" name="surname" placeholder="Enter your last name">
            </div>
            <div class="form-group">
                <label for="surname">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username">
            </div>
            <div class="form-group">
                <label for="surname">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>    
    </div>
</div>

<?php
  Helper::getFooter();
?>