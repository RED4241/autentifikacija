<?php

return [
    'remember' => [
        'cookie_name' => 'hash',
        'cookie_expiery' => 60*60*24*7
    ],
    'session' => [
        'session_name' => 'user',
        'token_name' => 'token'
    ]
]

?>