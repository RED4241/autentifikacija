<?php
    require_once "core/init.php";
    Helper::getHeader('Home Page');
    Helper::getNav();

    if (Input::exists('get')){
        $userId = Input::get('id');
        $user = DB::getInstance()->get('*', 'users', ['id', '=', $userId])->first();
    }
    
    if (Input::exists()) {
        $userId = Input::get('id');
        $user = DB::getInstance()->delete('users', ['id', '=', $userId]);
        if (!$user->getError()){
            header("Location: all-users.php");
        }
    }
    //echo Input::get('id');
    //dd($user);

?>

    <div class="row">
    <div class="col-lg-8 offset-lg-2" >
        <div class="card m-5">
        <h5 class="card-title p-2">Jeste li sigurni da želite obrisati korisnika <i><?php echo $user->first_name . ' ' . $user->last_name . '?'?></i></h5>
            <div class="card-body"> 
               <p>Ime: <?php echo $user->first_name ?></p>
               <p>Prezime: <?php echo $user->last_name ?></p>
               <p>Rola: <?php echo $user->role_id ?></p>
               <p>Username: <?php echo $user->username ?></p>
               <p>Datum Registracije: <?php echo $user->joined ?></p>
               <form method="post" class="p=3">
                    <input type="hidden" name="id" value="<?php echo $userId?>">
                    <a href="all-users.php" class="btn btn-warning">Nazad</a>
                    <button type="submit" name="submit" class="btn btn-primary" style="float:right">Potvrdi</a>
               </form>
            </div> 
        </div>    
    </div>
</div>

<?php
  Helper::getFooter();
?>