<?php
  require_once "core/init.php";
  Helper::getHeader('Home Page');
  Helper::getNav();

  if (Input::exists('get')){
    $userId = Input::get('id');
    $user = DB::getInstance()->get('*', 'users', ['id', '=', $userId])->first();
}

if (Input::exists()){
    //echo Input::get('first_name');
    $user = DB::getInstance()->update('users', [
        'username' => Input::get('username'),
        'password' => Input::get('password'),
        'salt' => 'dfsawe',
        'first_name' => Input::get('first_name'),
        'last_name' => Input::get('last_name'),
        'role_id' => 1
    ], Input::get('id'));
    
    if (!$user->getError()){
        header("Location: all-users.php");
    }
}
 
?>

<div class="row">
    <div class="col-lg-8 offset-lg-2" >
    <div class="card m-5">
    
    <h5 class="card-title p-2">Uredi korisnika</h5>
    <div class="card-body">
            <form method="POST">
            <input type="hidden" name="id" value="<?php echo $userId?>">
            <div class="form-group">
                <label for="first_name">First Name</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $user->first_name?>">
            </div>
            <div class="form-group">
                <label for="last_name">Last Name</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $user->last_name?>">
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $user->username?>">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" value="<?php echo $user->password?>">
            </div>
            <a href="all-users.php" class="btn btn-warning">Nazad</a>
            <button type="submit" class="btn btn-primary" style="float:right">Uredi</button>
            </form>
        </div>    
        </div>    
    </div>
</div>
</div>
</div>

<?php
  Helper::getFooter();
?>